"""
Task 1: Basic Neural Network from Scratch (NumPy only) - digit classification.
Architecture: 64 -> 32 (ReLU) -> 10 (Softmax), trained with mini-batch gradient descent.

Data: uses the 8x8 digits dataset. sklearn's load_digits is used ONLY to load the data
(no ML model/library is used for training). If sklearn isn't installed, a synthetic
NumPy-generated digit dataset is used so the script always runs.
"""
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

np.random.seed(42)


# ---------- Data ----------
def load_data():
    try:
        from sklearn.datasets import load_digits  # data loader only
        d = load_digits()
        X, y = d.data / 16.0, d.target
        print("Loaded real 8x8 digits dataset:", X.shape)
    except ImportError:
        print("sklearn not found -> generating synthetic digits with NumPy")
        X, y = make_synthetic()
    idx = np.random.permutation(len(X))
    X, y = X[idx], y[idx]
    split = int(0.8 * len(X))
    return X[:split], y[:split], X[split:], y[split:]


def make_synthetic(n_per_class=150):
    """Noisy 8x8 prototype digits (fallback only)."""
    protos = np.random.RandomState(0).rand(10, 64) > 0.6
    X, y = [], []
    for c in range(10):
        for _ in range(n_per_class):
            flip = np.random.rand(64) < 0.08
            X.append(np.logical_xor(protos[c], flip).astype(float))
            y.append(c)
    return np.array(X), np.array(y)


def one_hot(y, k=10):
    out = np.zeros((len(y), k))
    out[np.arange(len(y)), y] = 1
    return out


# ---------- Activations ----------
def relu(z): return np.maximum(0, z)
def relu_grad(z): return (z > 0).astype(float)

def softmax(z):
    z = z - z.max(axis=1, keepdims=True)  # numerical stability
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


# ---------- Network ----------
class NeuralNetwork:
    def __init__(self, n_in=64, n_hidden=32, n_out=10, lr=0.1):
        self.lr = lr
        self.W1 = np.random.randn(n_in, n_hidden) * np.sqrt(2 / n_in)   # He init
        self.b1 = np.zeros((1, n_hidden))
        self.W2 = np.random.randn(n_hidden, n_out) * np.sqrt(2 / n_hidden)
        self.b2 = np.zeros((1, n_out))

    def forward(self, X):
        self.Z1 = X @ self.W1 + self.b1
        self.A1 = relu(self.Z1)
        self.Z2 = self.A1 @ self.W2 + self.b2
        self.A2 = softmax(self.Z2)
        return self.A2

    @staticmethod
    def loss(probs, Y):
        return -np.mean(np.sum(Y * np.log(probs + 1e-9), axis=1))  # cross-entropy

    def backward(self, X, Y):
        m = X.shape[0]
        dZ2 = (self.A2 - Y) / m
        dW2 = self.A1.T @ dZ2
        db2 = dZ2.sum(axis=0, keepdims=True)
        dZ1 = (dZ2 @ self.W2.T) * relu_grad(self.Z1)
        dW1 = X.T @ dZ1
        db1 = dZ1.sum(axis=0, keepdims=True)
        self.W2 -= self.lr * dW2; self.b2 -= self.lr * db2
        self.W1 -= self.lr * dW1; self.b1 -= self.lr * db1

    def predict(self, X):
        return np.argmax(self.forward(X), axis=1)


def accuracy(pred, y): return np.mean(pred == y)


# ---------- Train + visualize ----------
def main(epochs=60, batch=32):
    Xtr, ytr, Xte, yte = load_data()
    Ytr, Yte = one_hot(ytr), one_hot(yte)
    net = NeuralNetwork()
    hist = {"loss": [], "val_loss": [], "acc": [], "val_acc": []}

    for ep in range(1, epochs + 1):
        perm = np.random.permutation(len(Xtr))
        for i in range(0, len(Xtr), batch):
            b = perm[i:i + batch]
            net.forward(Xtr[b]); net.backward(Xtr[b], Ytr[b])
        p_tr, p_te = net.forward(Xtr), net.forward(Xte)
        hist["loss"].append(net.loss(p_tr, Ytr)); hist["val_loss"].append(net.loss(p_te, Yte))
        hist["acc"].append(accuracy(p_tr.argmax(1), ytr)); hist["val_acc"].append(accuracy(p_te.argmax(1), yte))
        if ep % 5 == 0 or ep == 1:
            print(f"Epoch {ep:3d} | loss {hist['loss'][-1]:.4f} | train acc {hist['acc'][-1]:.3f} | test acc {hist['val_acc'][-1]:.3f}")

    pred = net.predict(Xte)
    print(f"\nFinal TEST accuracy: {accuracy(pred, yte) * 100:.2f}%")

    # confusion matrix
    cm = np.zeros((10, 10), dtype=int)
    for t, p in zip(yte, pred): cm[t, p] += 1

    fig, ax = plt.subplots(2, 2, figsize=(12, 9))
    ax[0, 0].plot(hist["loss"], label="train"); ax[0, 0].plot(hist["val_loss"], label="test")
    ax[0, 0].set_title("Loss"); ax[0, 0].set_xlabel("epoch"); ax[0, 0].legend()
    ax[0, 1].plot(hist["acc"], label="train"); ax[0, 1].plot(hist["val_acc"], label="test")
    ax[0, 1].set_title("Accuracy"); ax[0, 1].set_xlabel("epoch"); ax[0, 1].legend()
    im = ax[1, 0].imshow(cm, cmap="Blues"); ax[1, 0].set_title("Confusion matrix")
    ax[1, 0].set_xlabel("predicted"); ax[1, 0].set_ylabel("true"); fig.colorbar(im, ax=ax[1, 0])
    ax[1, 0].set_xticks(range(10)); ax[1, 0].set_yticks(range(10))
    ax[1, 1].axis("off")
    ax[1, 1].set_title("Sample predictions (green=correct, red=wrong)")
    for k in range(12):
        sub = fig.add_axes([0.54 + (k % 4) * 0.115, 0.30 - (k // 4) * 0.12, 0.10, 0.10])
        sub.imshow(Xte[k].reshape(8, 8), cmap="gray_r"); sub.axis("off")
        sub.set_title(f"{pred[k]}", color="green" if pred[k] == yte[k] else "red", fontsize=10)
    fig.subplots_adjust(hspace=0.35, wspace=0.25)
    plt.savefig("nn_results.png", dpi=120)
    print("Saved plot -> nn_results.png")
    if matplotlib.get_backend().lower() != "agg":
        plt.show()


if __name__ == "__main__":
    main()
